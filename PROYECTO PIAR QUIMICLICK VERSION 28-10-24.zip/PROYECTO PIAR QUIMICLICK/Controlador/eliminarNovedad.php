<?php
session_start();
require_once './conexion/conexion.php'; // Archivo para la conexión a la base de datos

// Verificar la conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Obtener el ID del reto a eliminar
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Consulta para eliminar el reto
    $sql = "DELETE FROM nnovedades  WHERE id = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        $_SESSION['success'] = "Novedad eliminada exitosamente.";
    } else {
        $_SESSION['error'] = "Error al eliminar la novedad: " . $conexion->error;
    }
    $stmt->close();
} else {
    $_SESSION['error'] = "ID de reto no proporcionado.";
}

// Redirigir de vuelta a la página de retos
header("Location: ../Vista/Novedades.php");
exit();
?>
